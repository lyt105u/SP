#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define MAXLINE 4096

static void sig_pipe(int);

int main(void) {
    pid_t pid;
    char line[MAXLINE];
    FILE *fp1_read, *fp1_write, *fp2_read, *fp2_write;
	int fd1[2], fd2[2];

    if (signal(SIGPIPE, sig_pipe) == SIG_ERR) {
        perror("signal error");
        return 1;
    }

    if (pipe(fd1) < 0 || pipe(fd2) < 0) {
        perror("pipe error");
        return 1;
    }

    if ((pid = fork()) < 0) {
        perror("fork error");
        return 1;
    } else if (pid > 0) { /* parent */
        close(fd1[0]);
        close(fd2[1]);

        fp1_write = fdopen(fd1[1], "w");
        fp2_read = fdopen(fd2[0], "r");

        while (fgets(line, MAXLINE, stdin) != NULL) {
            if (fputs(line, fp1_write) == EOF) {
                perror("fputs error to pipe");
                return 1;
            }
            fflush(fp1_write); // Ensure the data is sent immediately

            if (fgets(line, MAXLINE, fp2_read) == NULL) {
                if (feof(fp2_read)) {
                    printf("child closed pipe\n");
                    break;
                } else {
                    perror("fgets error from pipe");
                    return 1;
                }
            }
            if (fputs(line, stdout) == EOF) {
                perror("fputs error");
                return 1;
            }
        }

        fclose(fp1_write);
        fclose(fp2_read);
        if (ferror(stdin)) {
            perror("fgets error on stdin");
            return 1;
        }
        exit(0);
    } else { /* child */
        close(fd1[1]);
        close(fd2[0]);

        fp1_read = fdopen(fd1[0], "r");
        fp2_write = fdopen(fd2[1], "w");

        if (dup2(fileno(fp1_read), STDIN_FILENO) != STDIN_FILENO) {
            perror("dup2 error to stdin");
            return 1;
        }
        fclose(fp1_read);

        if (dup2(fileno(fp2_write), STDOUT_FILENO) != STDOUT_FILENO) {
            perror("dup2 error to stdout");
            return 1;
        }
        fclose(fp2_write);

        if (execl("./add2", "add2", (char *)0) < 0) {
            perror("execl error");
            return 1;
        }
    }
    exit(0);
}

static void sig_pipe(int signo) {
    printf("SIGPIPE caught\n");
    exit(1);
}
