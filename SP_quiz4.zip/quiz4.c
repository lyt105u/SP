#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>

#define SEM_NAME "/my_sem"
#define BUF_SIZE 1024

char buf[BUF_SIZE];
sem_t *sem;
volatile int done_reading = 0;
int bytes = 0;

void* read_thread(void* arg) {
    int total_byte;
    int xfrs;

    for (xfrs = 0, total_byte = 0; ; xfrs++) {
        sem_wait(sem);

        // read
        bytes = read(STDIN_FILENO, buf, BUF_SIZE);
        if(bytes == -1) {
            perror("read");
            break;
        }

        // end of file
        if(bytes == 0) {
            break;
        }

        total_byte += bytes;

        usleep(10000);
        sem_post(sem);
        usleep(10000);
    }

    done_reading = 1;
    sem_post(sem);
    fprintf(stderr, "Sent %d bytes (%d xfrs)\n", total_byte, xfrs);
    return NULL;
}

void* write_thread(void* arg) {
    int xfrs;
    int total_byte;

    usleep(10);
    for (xfrs = 0, total_byte = 0; ; xfrs++) {
        sem_wait(sem);

        // finishing reading
        if (done_reading)
            break;

        // write
        if (write(STDOUT_FILENO, buf, bytes) != bytes)
            perror("partial/failed write");

        total_byte += bytes;

        usleep(10000);
        sem_post(sem);
        usleep(10000);
    }

    sem_post(sem);
    fprintf(stderr, "Received %d bytes (%d xfrs)\n", total_byte, xfrs);
    return NULL;
}

int main(int argc, char **argv) {
    pthread_t t1, t2;
    int s;

    // If semaphore exists, delete it and create a new one to reset value.
    sem = sem_open(SEM_NAME, 0);
    if (sem != SEM_FAILED) {
        sem_close(sem);
        sem_unlink(SEM_NAME);
    }
    sem = sem_open(SEM_NAME, O_CREAT, 0644, 1);
    if(sem == SEM_FAILED) {
        perror("sem_open");
        return 1;
    }

    // create sender thread
    s = pthread_create(&t1, NULL, read_thread, NULL);
    if (s != 0) {
        perror("t1 pthread_create");
        return 1;
    }

    // create receiver thread
    s = pthread_create(&t2, NULL, write_thread, NULL);
    if (s != 0) {
        perror("t2 pthread_create");
        return 1;
    }

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    // close and unlink semaphore
    if(sem_close(sem) == -1) {
        perror("sem_close");
        return 1;
    }
    if(sem_unlink(SEM_NAME) == -1) {
        perror("sem_unlink");
        return 1;
    }

    return 0;
}
