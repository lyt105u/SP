#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>

// Shared memory pointer
volatile int *shared_number;

void handler(int sig) {
    int sock;
    struct sockaddr_in server;

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        printf("Could not create socket");
    }
    server.sin_addr.s_addr = inet_addr("127.0.0.1"); // Localhost
    server.sin_family = AF_INET;

    // SMTP port
    // use "sudo netstat -tulnp | grep LISTEN" to verify
    server.sin_port = htons(631);

    // Connect to the SMTP server
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Connect failed. Error");
        return;
    }

    // Send some data
    char message[50];
    snprintf(message, sizeof(message), "This is type %d error.\n", *shared_number);
    if (send(sock, message, strlen(message), 0) < 0) {
        puts("Send failed");
        return;
    }

    printf("This is type %d error\n", *shared_number);
}

int main() {
    pid_t childPid;
    struct sigaction sa;

    // seed random
    srand(time(NULL));

    // allocate shared memory
    shared_number = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    // set up signal handler
    sa.sa_handler = &handler;
    sa.sa_flags = SA_RESTART;
    sigaction(SIGUSR1, &sa, NULL);

    childPid = fork();
    if(childPid == -1) {
        perror("fork");
        exit(1);
    } else if(childPid == 0) {
        while(1) {
            sleep(random()%9 + 1);
            *shared_number = random() % 3 + 1;
            if (kill(getppid(), SIGUSR1) == -1) {
                perror("kill");
                exit(1);
            }
        }
    } else {
        while(1) {
            pause(); // Wait for signals
        }
    }

    return 0;
}
