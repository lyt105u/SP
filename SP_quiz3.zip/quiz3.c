#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <time.h>

#define STACK_SIZE 20

typedef struct {
    int data[STACK_SIZE];
    int top;
    int semid;
} SharedStack;

// wait
void P(int semid) {
    struct sembuf p = {0, -1, SEM_UNDO};
    if (semop(semid, &p, 1) == -1) {
        perror("semop P");
        exit(1);
    }
}

// signal
void V(int semid) {
    struct sembuf v = {0, 1, SEM_UNDO};
    if (semop(semid, &v, 1) == -1) {
        perror("semop V");
        exit(1);
    }
}

void push(SharedStack *stack, int item, int pid) {
    P(stack->semid);
    printf("Process %d pushed ", pid);
    if (stack->top < STACK_SIZE - 1) {
        stack->top++;
        stack->data[stack->top] = item;
        printf("%d\n", item);
    } else {
        printf("failed: Stack overflow\n");
    }
    V(stack->semid);
}

void pop(SharedStack *stack, int pid) {
    printf("Process %d popped ", pid);
    P(stack->semid);
    if (stack->top >= 0) {
        printf("%d\n", stack->data[stack->top]);
        stack->top--;
    } else {
        printf("failed: Stack underflow\n");
    }
    V(stack->semid);
}

int main(int argc, char *argv[]) {
    int shmid, semid;
    pid_t pid;

    if(argc!=2 || atoi(argv[1])==0) {
        printf("Usage: %s <number_of_process>\n", argv[0]);
        return 1;
    }

    shmid = shmget(IPC_PRIVATE, sizeof(SharedStack), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    SharedStack *shared_stack = (SharedStack *)shmat(shmid, NULL, 0);
    if (shared_stack == (void *)-1) {
        perror("shmat");
        exit(1);
    }
    shared_stack->top = -1; // empty stack

    // Initialize semaphore
    semid = semget(IPC_PRIVATE, 1, IPC_CREAT | 0666);
    if (semid == -1) {
        perror("semget");
        exit(1);
    }

    if (semctl(semid, 0, SETVAL, 1) == -1) {
        perror("semctl");
        exit(1);
    }

    // Store semaphore ID in shared memory
    shared_stack->semid = semid;

    for(int i=0; i<atoi(argv[1]); i++) {
        pid = fork();
        srandom(i);
        if(pid < 0) {
            perror("fork");
            return 1;
        } else if (pid == 0) {
            srand(time(NULL) ^ getpid());
            int action = rand() % 2;
            if (action) {
                int item = rand() % 100;
                push(shared_stack, item, getpid());
            } else {
                pop(shared_stack, getpid());
            }
            // Detach from shared memory
            shmdt(shared_stack);
            exit(0);
        }
    }

    for (int i = 0; i < atoi(argv[1]); i++) {
        wait(NULL);
    }
    shmdt(shared_stack);
    shmctl(shmid, IPC_RMID, NULL);

    // Remove the semaphore only in the parent process
    if (semctl(semid, 0, IPC_RMID) == -1) {
        perror("semctl remove");
    }
}
