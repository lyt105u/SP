使用範例：
time ./sig_speed_sigsuspend 500
time ./sig_speed_sigwaitinfo 500